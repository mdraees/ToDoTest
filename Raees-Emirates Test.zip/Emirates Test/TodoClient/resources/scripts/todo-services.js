var todoServices = angular.module("todoServices",[]);

todoServices.service("todoService", function($http, $rootScope) {
	
	this.addToDo = function (todo) {
		return $http.post("http://"+$rootScope.config.serverip+":"+$rootScope.config.serverport+"/todo",JSON.stringify(todo));
	};
	this.getTodoList = function (todo) {
		console.log()
		return $http.get("http://"+$rootScope.config.serverip+":"+$rootScope.config.serverport+"/todo");
	};
	this.deleteTodo = function (id) {
		return $http.delete("http://"+$rootScope.config.serverip+":"+$rootScope.config.serverport+"/todo/"+id);
	};
	this.completed = function (todo) {
		return $http.put("http://"+$rootScope.config.serverip+":"+$rootScope.config.serverport+"/todo/",JSON.stringify(todo));
	};
});