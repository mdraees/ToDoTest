todoModules = angular.module("todo.controllers",["todoServices"]);

todoModules.controller("todoListController", function($scope,todoService,$timeout,$http,$rootScope){

	$scope.currentPage = 0;
	$scope.todoFilter=""
    $scope.pageSize = 5;
    $scope.totalPages = 0;
	$scope.sectionHeader = "ToDo List";
	$scope.todoList=[];
	todoListT=[]
	$scope.error = false;
	$scope.success = false;
	$scope.msg = "";
	$scope.total=0;
	$scope.columnSort = { sortColumn: 'createdDate', reverse: false }; 
	getList = function (){
		$scope.todoList = [];
		todoListT = [];
		todoService.getTodoList().then(function(data){
			$scope.todoList = data.data;
			todoListT = data.data;
			$scope.totalPages = Math.ceil($scope.todoList.length/$scope.pageSize);
			$scope.total=$scope.todoList.length;
		});
	}


	$http({method: 'GET', url: 'config.json'}).then(function (data){
   		$rootScope.config = data.data;
   		getList();
   	},function (error){
	});


	$scope.deleteTodo = function(id) {

		var res = confirm("Are you sure to delete the task?");
		if(res){
			todoService.deleteTodo(id).then(function(data){
			if(data.status == 200) {
				$scope.currentPage = 0;
				$scope.todoFilter=""
			    $scope.pageSize = 5;
			    $scope.totalPages = 0;
				getList();
			}
		});
		}
		
	}
	$scope.completed = function(todo){
		todoService.completed(todo).then(function(data){
			if(data.status == 200) {
				$scope.success = true;
				$scope.msg = "Task "+todo.taskName+" completed!";
				 $timeout(function() {
		console.log("here")
		$scope.error = false;
		$scope.success = false;
		$scope.msg = "";
	}, 2000);
			}else{
				$scope.error = true;
				$scope.msg = "Failed to comelete the task "+todo.taskName;
			}
			getList();
		});
	} 

    $scope.pageButtonDisabled = function(dir) {
    	if (dir == -1) {
			return $scope.currentPage == 0;
    	}
		return $scope.currentPage >= $scope.todoList.length/$scope.pageSize - 1;
    }

    $scope.paginate = function(nextPrevMultiplier) {
    	$scope.currentPage += (nextPrevMultiplier * 1);
    	$scope.todoList = todoListT.slice($scope.currentPage*$scope.pageSize);
    }



});

todoModules.controller("todoAddController", function($scope,todoService,$filter){
	$scope.sectionHeader = "New ToDo";
	$scope.todo = {};
	$scope.error = false;
	$scope.success = false;
	$scope.msg = "";
	$scope.submit = function(){
		$scope.error = false;
		$scope.success = false;
		$scope.msg = "";
		$scope.todo.dueDate = $filter('date')($scope.dueDate, "dd/MM/yyyy"); 
		todoService.addToDo($scope.todo).then(function(data){
			if(data.status == 200) {
				$scope.success = true;
				$scope.msg = "New Task added to ToDo List";
				$scope.todo ={};
				$scope.dueDate=null;
				getList();
				$scope.submitted = false
			} else{
				$scope.error = true;
				$scope.msg = "Failed to add new task!";
			}
		});
	}
});