/**
 * 
 */
package com.demo.todo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.todo.model.Todo;
import com.demo.todo.service.TodoService;
/**
 * @author raees
 *
 */
@RestController
@RequestMapping({ "/todo" })
public class TodoController {
	@Autowired
	TodoService todoService;
	@RequestMapping(method = { RequestMethod.POST })
	public Todo add(@RequestBody Todo todo) {
		return todoService.addTodo(todo);
	}
	@RequestMapping(method = { RequestMethod.GET })
	public List<Todo> get() {
		return todoService.getAllTodo();
	}
	@RequestMapping(value = "{taskName}", method = { RequestMethod.GET })
	public Todo getByName(@PathVariable("id") String id) {
		return todoService.getById(id);
	}
	@RequestMapping(value = "{id}", method = { RequestMethod.DELETE })
	public void deleteTodo(@PathVariable("id") String id) {
		todoService.deleteTodo(id);
	}
	@RequestMapping( method = { RequestMethod.PUT })
	public void update(@RequestBody Todo todo) {
		todoService.updateTodo(todo);
	}
	
}
