/**
 * 
 */
package com.demo.todo.service;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.demo.todo.dao.TodoRepository;
import com.demo.todo.model.ToDoStatus;
import com.demo.todo.model.Todo;

/**
 * @author raees
 *
 */
@Service
public class TodoService {

	@Autowired
    TodoRepository todoRepository;
	
	public Todo addTodo(Todo todo) {
		todo.setStatus(ToDoStatus.NEW);
		todo.setCreatedDate(new Date());
		return todoRepository.save(todo);
	}

	public List<Todo> getAllTodo() {
		return todoRepository.findAll(new Sort(Sort.Direction.DESC, "createdDate"));
	}

	public Todo getById(String id) {
		return todoRepository.findOne(id);
	}

	public void deleteTodo(String id) {
		todoRepository.delete(id);
	}

	public void updateTodo(Todo todo) {
		todo.setStatus(ToDoStatus.COMPLETED);
		todoRepository.save(todo);
	}

}
