/**
 * 
 */
package com.demo.todo.model;

/**
 * @author raees
 *
 */
public enum ToDoStatus {

	/**
	 * New Task
	 */
	NEW (1),
	
	/**
	 * Task Completed
	 */
	COMPLETED (3);
	

	private int mode;
	
	private ToDoStatus(int mode) {
		this.mode = mode;
	}
	
	public int mode() {
		return mode;
	}
	
	public static ToDoStatus valueOf(int type) {
		for (ToDoStatus vMode : values()) {
			if (vMode.mode == type)
				return vMode;
		}
		
		throw new IllegalArgumentException(
	            "No enum const ToDoStatus with type " + type);
	}
	
	public static ToDoStatus getEnum(int i){
		ToDoStatus[] status =  ToDoStatus.values();
		return status[i-1];
	}

	public static ToDoStatus OfName(String name) {
		for (ToDoStatus vMode : ToDoStatus.class.getEnumConstants()) {
			if (vMode.name().equals(name))
				return vMode;
		}
		
		throw new IllegalArgumentException(
	            "No enum ToDoStatus with name " + name);
	}
}

